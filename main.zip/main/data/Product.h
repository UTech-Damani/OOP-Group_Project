#ifndef PRODUCT_H
#define PRODUCT_H
#include <string>

#include "../universal/FileManager.h"
#include "../exceptions/InsufficientStockException.h"

// Since this class contains abstract methods/destructor, it is now an abstract class
class Product : public Persistable
{
    private:
        int productID;
        std::string productName;
        double price;
        int quantityInStock;

    public:
        // Creates an abstract method which must be implemented by all child class
        virtual void Display() = 0;

        //Default Constructor
        Product() {
            productID = 0;
            productName = "";
            price = 0.0;
            quantityInStock = 0;
        }

        //Primary Constructor
        Product(int pID, std::string pName, double cost, int quantity) {
            productID = pID;
            productName = pName;
            price = cost;
            quantityInStock = quantity;
        }

        // Sets the product ID
        void setProductID(int id) {
            productID = id;
        }

        // Returns the product ID
        int getProductID() const {
            return productID;
        }

        // Sets the product name
        void setProductName(std::string name) {
            productName = name;
        }

        // Returns the product name
        std::string getProductName() const {
            return productName;
        }

        // Sets the product price
        void setPrice(double p) {
            price = p;
        }

        // Returns the product price
        double getPrice() const {
            return price;
        }

        // Sets the quantity of the product in stock
        void setQuantityInStock(int quantity) {
            quantityInStock = quantity;
        }

        // Returns the quantity of the product in stock
        int getQuantityInStock() const {
            return quantityInStock;
        }

        bool isInStock() const {
            return quantityInStock > 0;
        }

        void increaseStock(int amount)
        {
            quantityInStock += amount;
        }

        void decreaseStock(int amount)
        {
            if (amount <= 0) {
                throw InsufficientStockException();
            }

            if (amount > quantityInStock) {
                throw InsufficientStockException();
            }
            quantityInStock -= amount;
        }

        virtual bool isTicket() const
        {
            return false;
        }


};

#endif // PRODUCT_H
